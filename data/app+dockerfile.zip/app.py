from flask import Flask
import os
import time
import grpc  # 新增grpc依赖
from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
from opentelemetry.instrumentation.flask import FlaskInstrumentor
from opentelemetry.instrumentation.requests import RequestsInstrumentor

# 关键：创建明文gRPC通道，关闭TLS加密
trace.set_tracer_provider(TracerProvider())
otel_endpoint = os.getenv("OTEL_EXPORTER_OTLP_ENDPOINT","jaeger-all-in-one.observability.svc.cluster.local:4317")
insecure_channel = grpc.insecure_channel(otel_endpoint)
# 通道传入导出器，不再只用endpoint参数
otlp_exporter = OTLPSpanExporter(channel=insecure_channel)

trace.get_tracer_provider().add_span_processor(BatchSpanProcessor(otlp_exporter))

app = Flask(__name__)
FlaskInstrumentor().instrument_app(app)
RequestsInstrumentor().instrument()

user_data = {
    "10086": {"level": "VIP", "credit": 888, "register_days": 365},
    "10001": {"level": "普通", "credit": 200, "register_days": 90},
    "10002": {"level": "VIP", "credit": 1200, "register_days": 500}
}

@app.route("/health")
def health():
    return {"status":"ok"}

# 正常接口（现有正常链路采集用）
@app.route("/api/user/info/<uid>")
def query_user(uid):
    u = user_data.get(uid,{"level":"未知","credit":0,"register_days":0})
    return {
        "service":"user-extra-svc",
        "user_id":uid,
        "level":u["level"],
        "credit":u["credit"],
        "register_days":u["register_days"]
    }

# 异常1：高延迟接口（制造时延异常Trace，duration超大）
@app.route("/api/user/slow/<uid>")
def slow_query(uid):
    # 强制休眠3秒，正常请求仅1ms左右，形成时延异常样本
    time.sleep(3)
    u = user_data.get(uid,{"level":"未知","credit":0,"register_days":0})
    return {
        "service":"user-extra-svc",
        "user_id":uid,
        "level":u["level"],
        "credit":u["credit"],
        "register_days":u["register_days"]
    }

# 异常2：主动崩溃接口（抛出除零错误，自动生成500状态码异常Trace）
@app.route("/api/user/crash/<uid>")
def crash(uid):
    # 主动抛出异常，opentelemetry会记录http.status_code=500
    1 / 0
    return {}

@app.route("/api/user/credit/deduct/<uid>/<num>")
def deduct(uid,num):
    num = int(num)
    u = user_data[uid]
    u["credit"] -= num
    return {
        "service":"user-extra-svc",
        "user_id":uid,
        "deduct_num":num,
        "remaining_credit":u["credit"],
        "status":"扣除成功"
    }

if __name__ == "__main__":
    app.run(host="0.0.0.0",port=8080)